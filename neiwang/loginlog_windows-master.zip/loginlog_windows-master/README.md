# loginlog_windows

EventLog 读取 
可读取登录过本机的登录失败或登录成功的所有计算机信息，包括用户名、远程IP地址、时间。

![](https://github.com/uknowsec/loginlog_windows/blob/master/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190829150215.png)



# Reference
https://github.com/ysrc/yulong-hids

https://mp.weixin.qq.com/s/rHDJ2tQWEaZLikMt5bgCsw

